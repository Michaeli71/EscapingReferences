package escaping;


import java.util.Arrays;

public class EscapingExampleCorrected {
public static void main(String[] args) 
{
	MainServiceCorrected.createMainService();
}

	static class MainServiceCorrected 
	{
		private CallBack caller;
		private final String info;
	
		public MainServiceCorrected() 
		{
			info = "Initialized " + MainServiceCorrected.class.getSimpleName();
		}
	
		public String getInfo() 
		{
			return info;
		}
	
		static MainServiceCorrected createMainService() 
		{
			MainServiceCorrected service = new MainServiceCorrected();
			service.caller = new CallBack(service);
			return service;
		}
	}

	static class CallBack 
	{
		private final MainServiceCorrected mainService;
	
		CallBack(final MainServiceCorrected mainService) 
		{
			this.mainService = mainService;
			
			final byte[] infoAsBytes = mainService.getInfo().getBytes();
			System.out.println(Arrays.toString(infoAsBytes));
		}
	}
}
