package escaping;

import java.util.Arrays;

// Java-Profi
public class EscapingExample 
{
	public static void main(String[] args) 
	{
		new MainService();
	}

	static class MainService {
		private final CallBack caller;
		private final String info;

		public MainService() {
			caller = new CallBack(this);
			info = "Initialized " + MainService.class.getSimpleName();
		}

		public String getInfo() {
			return info;
		}
	}

	static class CallBack {
		private final MainService mainService;

		public CallBack(final MainService mainService) {
			this.mainService = mainService;

			// Zugriff auf Methode der teilinitialisierten(!) Klasse MainService
			final byte[] infoAsBytes = mainService.getInfo().getBytes();
			System.out.println(Arrays.toString(infoAsBytes));
		}
	}
}
