package references;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

// Java-Profi
public class ReferenceProblems {

    // DateRange without Immutability
    // => unexpected changes

    // Person
    // List<String> hobbies => unexpected changes
    // String[] pizzaTop3Favorites => unexpected changes
    record Person(String name, List<String> hobbies, String[] pizzaTop3Favorites) {

        void changePizzaPreference(int pos, String newPreference)
        {
            pizzaTop3Favorites[pos] = newPreference;
        }

        @Override
        public String toString() {
            return "Person{" +
                    "name='" + name + '\'' +
                    ", hobbies=" + hobbies +
                    ", pizzaTop3Favorites=" + Arrays.toString(pizzaTop3Favorites) +
                    '}';
        }
    }

    //

    public static void main(String[] args) {

        var hobbies = new ArrayList<>(List.of("Ski", "Wandern", "Java"));
        var globalPizzaTop3 = new String[] { "Diavolo", "Funghi", "Salame"};

        var andrzej = new Person("Andzej", hobbies, globalPizzaTop3);

        System.out.println(andrzej);

        // unerwartet => Referenz auf "mutable" Liste
        List<String> hobbies1 = andrzej.hobbies();
        hobbies1.add("Python");
        System.out.println(andrzej);

        // unerwartet => Referenz in die Datenstruktur reingegeben, draussen geändert, drinnen sichtbar
        globalPizzaTop3[1] = "Quadro Stagione";
        System.out.println(andrzej);

        // ändert leider auch beides
        andrzej.changePizzaPreference(0, "Margaritha");
        System.out.println(andrzej);
        System.out.println("globalPizzaTop3:" + Arrays.asList(globalPizzaTop3));

        // Abhilfe:
        // 1) Kopie beim reingeben
        // 2) Kopie beium rausgeben oder Collections.unmodifiable()

        var contract = new Contract(List.of("CLAIM"));
        List<String> claims = contract.claims();

        // Umsortieren, auch in internen Daten
        claims.sort(Comparator.naturalOrder());
    }

    record Contract(List<String> claims) {}
}
