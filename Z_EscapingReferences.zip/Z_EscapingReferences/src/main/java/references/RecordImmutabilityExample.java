package references;

import java.util.Date;

public class RecordImmutabilityExample {
    public static void main(String[] args) {
        record DateRange(Date start, Date end) {
            // Step 1
            DateRange
            {
                if (!start.before(end))
                    throw new IllegalArgumentException("start >= end");
            }

            // Abhilfe 2: verhindert interne Änderung
            public Date start()
            {
                // Kopie
                return new Date(start.getTime());
            }
        }

        DateRange range1 = new DateRange(new Date(71, 1, 7), new Date(71, 2, 27));
        System.out.println(range1);

        /*
        DateRange range2 = new DateRange(new Date(71, 6, 7), new Date(71, 2, 27));
        System.out.println(range2);
         */

        // Schlupfloch: Referenzsemantik, holen von Start und modifizieren
        Date startDate = range1.start();
        startDate.setTime(new Date(71,6,7).getTime());
        System.out.println(range1);
        System.out.println(startDate);
    }

    /*
    record DateRange(LocalDate start, LocalDate end)
{
    DateRange
    {
        if (!start.isBefore(end))
            throw new IllegalArgumentException("start >= end");
    }
}
     */
}