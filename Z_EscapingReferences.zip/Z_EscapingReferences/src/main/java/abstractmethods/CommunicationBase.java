package abstractmethods;

public abstract class CommunicationBase {
	CommunicationBase() {
		createComponents();
	}

	abstract protected void createComponents();
}