package abstractmethods;

public final class RadioCommunication extends CommunicationBase {
	// Definition des Synchronisationsobjekts
	private final Object sharedSyncObject = new Object();

	private RadioSender dataSender = null;

	//private RadioReceiver dataReader = null;

	@Override
	protected final void createComponents() {
		// Übergabe des Synchronisationsobjekts
		dataSender = new RadioSender(sharedSyncObject);
		// ...
	}
		
	
	public static void main(String[] args)
	{
		var radioCommunication = new RadioCommunication();
		
		radioCommunication.dataSender.send(new byte[] { 64, 65, 66, 67 });
	}
}