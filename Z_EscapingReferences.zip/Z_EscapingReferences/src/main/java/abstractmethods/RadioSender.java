package abstractmethods;

import java.util.Arrays;

public final class RadioSender {
	private final Object sharedSyncObject;

	public RadioSender(final Object sharedSyncObject) {
		this.sharedSyncObject = sharedSyncObject;
	}

	public void send(final byte[] msg) {
		synchronized (sharedSyncObject) {
			sendBytes(msg);
		}
	}

	private void sendBytes(final byte[] msg) {
		// ..
		System.out.println(Arrays.toString(msg));
	}
}